<?php
class Home extends CI_Controller {
  //render view
  public function index() {
    $this->load->view('home/index');
  }
  
}
?>